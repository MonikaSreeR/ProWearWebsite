import { ReactNode } from 'react';
import { Box, Drawer, List, ListItem, ListItemIcon, ListItemText, Typography, useTheme, CssBaseline, MenuItem, FormControl, InputLabel, Select } from '@mui/material';
import {
  Dashboard as DashboardIcon,
  Analytics as AnalyticsIcon,
  ShoppingBag as ProductsIcon,
  People as CustomersIcon,
  Settings as SettingsIcon,
  Inventory as InventoryIcon,
  Menu as MenuIcon,
  ChevronLeft,
} from '@mui/icons-material';
import { useNavigate, useLocation, Outlet } from 'react-router-dom';
import { useState, createContext, useContext } from 'react';
import Logo from './Logo';
import { useTheme as useCustomTheme } from '../context/ThemeContext';
import ChatBot from './ChatBot';
import { ThemeProvider } from '../context/ThemeContext';
import { DataProvider } from '../context/DataContext';

interface LayoutProps {
  children: ReactNode;
}

interface Filters {
  ageGroup: string;
  gender: string;
  state: string;
  city: string;
}

interface FilterContextType {
  filters: Filters;
  handleFilterChange: (filter: keyof Filters, value: string) => void;
}

const defaultFilters: Filters = {
  ageGroup: 'all',
  gender: 'all',
  state: 'all',
  city: 'all'
};

export const FilterContext = createContext<FilterContextType>({
  filters: defaultFilters,
  handleFilterChange: () => {}
});

const drawerWidth = 240;

const menuItems = [
  { text: 'Dashboard', icon: <DashboardIcon />, path: '/' },
  { text: 'Analytics', icon: <AnalyticsIcon />, path: '/analytics' },
  { text: 'Products', icon: <ProductsIcon />, path: '/products' },
  { text: 'Customers', icon: <CustomersIcon />, path: '/customers' },
  { text: 'Settings', icon: <SettingsIcon />, path: '/settings' },
];

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [filters, setFilters] = useState<Filters>(defaultFilters);
  const { darkMode } = useCustomTheme();

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleFilterChange = (filter: keyof Filters, value: string) => {
    setFilters(prev => ({ ...prev, [filter]: value }));
  };

  const drawer = (
    <Box>
      <Box sx={{ 
        p: 2, 
        display: 'flex', 
        alignItems: 'center', 
        gap: 1,
        borderBottom: '1px solid rgba(0, 0, 0, 0.12)',
        mb: 1
      }}>
        <Box
          sx={{
            width: 32,
            height: 32,
            borderRadius: '50%',
            bgcolor: 'white',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          }}
        >
          <Typography
            variant="h6"
            sx={{
              color: '#FF9933',
              fontWeight: 'bold',
              fontSize: '1.2rem',
            }}
          >
            P
          </Typography>
        </Box>
        <Box>
          <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#FF9933' }}>
            ProWear
          </Typography>
          <Typography variant="caption" sx={{ opacity: 0.9, fontSize: '0.7rem', color: '#FF9933' }}>
            Premium Clothing
          </Typography>
        </Box>
      </Box>
      <List>
        {menuItems.map((item) => (
          <ListItem
            button
            key={item.path}
            onClick={() => navigate(item.path)}
            sx={{
              '&:hover': {
                bgcolor: darkMode ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.04)',
              },
            }}
          >
            <ListItemIcon sx={{ color: '#FF9933' }}>
              {item.icon}
            </ListItemIcon>
            <ListItemText primary={item.text} />
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <ThemeProvider>
      <DataProvider>
        <FilterContext.Provider value={{ filters, handleFilterChange }}>
          <Box sx={{ display: 'flex', minHeight: '100vh' }}>
            <CssBaseline />
            <Drawer
              variant="permanent"
              sx={{
                width: drawerWidth,
                flexShrink: 0,
                '& .MuiDrawer-paper': {
                  width: drawerWidth,
                  boxSizing: 'border-box',
                  borderRight: '1px solid rgba(0, 0, 0, 0.12)',
                  bgcolor: darkMode ? '#1a1a1a' : '#fff',
                },
              }}
            >
              {drawer}
            </Drawer>
            <Box
              component="main"
              sx={{
                flexGrow: 1,
                p: 3,
                width: `calc(100% - ${drawerWidth}px)`,
                bgcolor: darkMode ? '#121212' : '#f5f5f5',
                minHeight: '100vh',
              }}
            >
              {children}
            </Box>
            <ChatBot onClose={() => {}} />
          </Box>
        </FilterContext.Provider>
      </DataProvider>
    </ThemeProvider>
  );
};

export default Layout; 