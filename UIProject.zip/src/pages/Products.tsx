import { Grid, Card, CardContent, Typography, Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Chip } from '@mui/material';

// Dummy product data
const products = [
  {
    category: 'Trousers',
    variants: [
      { name: 'Classic', price: '₹1500-₹3000', inventory: 25 },
      { name: 'Slim', price: '₹1800-₹3200', inventory: 15 },
      { name: 'Tailored', price: '₹2000-₹3500', inventory: 8 },
    ],
  },
  {
    category: 'Blazers',
    variants: [
      { name: 'Single-Breasted', price: '₹3000-₹5000', inventory: 20 },
      { name: 'Double-Breasted', price: '₹3500-₹5500', inventory: 12 },
      { name: 'Notch', price: '₹3200-₹5200', inventory: 18 },
    ],
  },
  {
    category: 'Skirts',
    variants: [
      { name: 'Pencil', price: '₹1200-₹2500', inventory: 30 },
      { name: 'A-Line', price: '₹1500-₹2800', inventory: 22 },
      { name: 'Pleated', price: '₹1800-₹3000', inventory: 15 },
    ],
  },
  {
    category: 'Shirts',
    variants: [
      { name: 'Dress', price: '₹900-₹2000', inventory: 40 },
      { name: 'Oxford', price: '₹1200-₹2200', inventory: 35 },
      { name: 'Button-Down', price: '₹1000-₹2100', inventory: 28 },
    ],
  },
  {
    category: 'Ties',
    variants: [
      { name: 'Silk', price: '₹900-₹1500', inventory: 50 },
      { name: 'Knit', price: '₹1000-₹1600', inventory: 45 },
      { name: 'Patterned', price: '₹1100-₹1700', inventory: 40 },
    ],
  },
  {
    category: 'Belts',
    variants: [
      { name: 'Leather', price: '₹900-₹2000', inventory: 30 },
      { name: 'Buckle', price: '₹1000-₹2200', inventory: 25 },
      { name: 'Formal', price: '₹1100-₹2300', inventory: 20 },
    ],
  },
];

const Products = () => {
  const getInventoryStatus = (inventory: number) => {
    if (inventory < 10) return <Chip label="Low Stock" color="error" />;
    if (inventory < 20) return <Chip label="Medium Stock" color="warning" />;
    return <Chip label="In Stock" color="success" />;
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Products
      </Typography>
      <Grid container spacing={3}>
        {/* Product Catalog */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Product Catalog
              </Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Category</TableCell>
                      <TableCell>Variant</TableCell>
                      <TableCell>Price Range</TableCell>
                      <TableCell>Inventory</TableCell>
                      <TableCell>Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {products.map((product) =>
                      product.variants.map((variant) => (
                        <TableRow key={`${product.category}-${variant.name}`}>
                          <TableCell>{product.category}</TableCell>
                          <TableCell>{variant.name}</TableCell>
                          <TableCell>{variant.price}</TableCell>
                          <TableCell>{variant.inventory}</TableCell>
                          <TableCell>
                            {getInventoryStatus(variant.inventory)}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Inventory Analytics */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Low Stock Alerts
              </Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Product</TableCell>
                      <TableCell>Inventory</TableCell>
                      <TableCell>Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {products
                      .flatMap((product) =>
                        product.variants.map((variant) => ({
                          name: `${product.category}: ${variant.name}`,
                          inventory: variant.inventory,
                        }))
                      )
                      .filter((item) => item.inventory < 10)
                      .map((item) => (
                        <TableRow key={item.name}>
                          <TableCell>{item.name}</TableCell>
                          <TableCell>{item.inventory}</TableCell>
                          <TableCell>
                            <Chip label="Low Stock" color="error" />
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Product Performance */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Top Performing Products
              </Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Product</TableCell>
                      <TableCell>Revenue</TableCell>
                      <TableCell>Units Sold</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableRow>
                      <TableCell>Blazer: Single-Breasted</TableCell>
                      <TableCell>₹2,50,000</TableCell>
                      <TableCell>75</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Trousers: Classic</TableCell>
                      <TableCell>₹1,80,000</TableCell>
                      <TableCell>120</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Shirt: Dress</TableCell>
                      <TableCell>₹1,50,000</TableCell>
                      <TableCell>150</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Products; 