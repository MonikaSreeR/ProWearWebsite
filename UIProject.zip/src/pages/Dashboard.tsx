import React from 'react';
import { Box, Grid, Card, CardContent, Typography } from '@mui/material';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { useTheme as useCustomTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer as RechartsResponsiveContainer, BarChart, Bar, Legend } from 'recharts';

interface DataPoint {
  date: string;
  revenue: number;
  sales: number;
  orders: number;
  customers: number;
  quantity: number;
  product: string;
  state: string;
}

const stateData = [
  { name: 'Maharashtra', value: 250000 },
  { name: 'Karnataka', value: 180000 },
  { name: 'Delhi', value: 150000 },
  { name: 'Tamil Nadu', value: 120000 },
  { name: 'Gujarat', value: 100000 },
  { name: 'Rajasthan', value: 90000 },
  { name: 'Telangana', value: 85000 },
  { name: 'West Bengal', value: 80000 }
];

const productData = [
  { name: 'Blazers', value: 85000 },
  { name: 'Trousers', value: 78000 },
  { name: 'Shirts', value: 72000 },
  { name: 'Skirts', value: 68000 },
  { name: 'Ties', value: 65000 },
  { name: 'Belts', value: 60000 }
];

const genderData = [
  { name: 'Male', value: 65 },
  { name: 'Female', value: 35 }
];

const ageGroupData = [
  { name: '10-18', value: 15 },
  { name: '19-35', value: 55 },
  { name: '36-70', value: 30 }
];

const COLORS = ['#FF9933', '#2C3E50', '#FF6B6B', '#4ECDC4', '#45B7D1'];
const GENDER_COLORS = ['#2C3E50', '#FF6B6B'];
const AGE_COLORS = ['#FF9933', '#2C3E50', '#4ECDC4'];

const Dashboard = () => {
  const theme = useCustomTheme();
  const { stateData } = useData();

  // Update the generateDummyData function
  const generateDummyData = () => {
    const data = [];
    const today = new Date();
    const days = 30; // Generate 30 days of data

    for (let i = 0; i < days; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() - (days - 1 - i));
      
      const day = date.getDate();
      const month = date.toLocaleString('default', { month: 'short' });
      const year = date.getFullYear();
      
      // Generate realistic daily values
      const baseRevenue = 25000 + Math.random() * 5000; // Daily revenue between 25,000-30,000
      const baseSales = 250 + Math.random() * 50; // Daily sales between 250-300
      
      data.push({
        date: `${day} ${month} ${year}`,
        revenue: baseRevenue,
        sales: baseSales,
        orders: Math.floor(200 + Math.random() * 40), // Daily orders between 200-240
        customers: Math.floor(160 + Math.random() * 30), // Daily customers between 160-190
        quantity: Math.floor(50 + Math.random() * 10), // Daily quantity between 50-60
        product: 'Product A',
        state: 'California'
      });
    }
    
    return data;
  };

  // Update the calculateMetrics function
  const calculateMetrics = (data: DataPoint[]) => {
    const totalRevenue = data.reduce((sum, item) => sum + (item.revenue || 0), 0);
    const totalOrders = data.reduce((sum, item) => sum + (item.orders || 0), 0);
    const totalCustomers = data.reduce((sum, item) => sum + (item.customers || 0), 0);
    const totalQuantity = data.reduce((sum, item) => sum + (item.quantity || 0), 0);

    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    const averageCustomerValue = totalCustomers > 0 ? totalRevenue / totalCustomers : 0;
    const averageQuantityPerOrder = totalOrders > 0 ? totalQuantity / totalOrders : 0;

    return {
      totalRevenue,
      totalOrders,
      totalCustomers,
      totalQuantity,
      averageOrderValue,
      averageCustomerValue,
      averageQuantityPerOrder
    };
  };

  // Calculate metrics for 3 years with realistic values
  const yearlyRevenue = 750000; // Base yearly revenue
  const yearlySales = 7500; // Base yearly sales
  const yearlyOrders = 6000; // Base yearly orders
  const yearlyCustomers = 5000; // Base yearly customers

  // 3-year totals
  const totalRevenue = yearlyRevenue * 3;
  const totalSales = yearlySales * 3;
  const totalOrders = yearlyOrders * 3;
  const totalCustomers = yearlyCustomers * 3;
  const customerRetentionRate = 85;
  const conversionRate = Math.round((totalOrders / totalCustomers) * 100);
  const topPerformingState = stateData.reduce((max, current) => 
    current.value > max.value ? current : max
  ).name;
  const topPerformingProduct = productData.reduce((max, current) => 
    current.value > max.value ? current : max
  ).name;

  return (
    <Box>
      <Typography variant="h4" sx={{ mb: 3 }}>
        Dashboard
      </Typography>

      <Grid container spacing={3}>
        {/* Revenue Metrics */}
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Total Revenue
              </Typography>
              <Typography variant="h4" component="div">
                ₹{totalRevenue.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                Total revenue
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* Sales Metrics */}
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Total Sales
              </Typography>
              <Typography variant="h4" component="div">
                {totalSales.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                Units sold
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Total Orders
              </Typography>
              <Typography variant="h4" component="div">
                {totalOrders.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                Total orders
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Top Performing Product
              </Typography>
              <Typography variant="h4" component="div">
                {topPerformingProduct}
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                Best selling product
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* Customer Metrics */}
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Total Customers
              </Typography>
              <Typography variant="h4" component="div">
                {totalCustomers.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                Total customers
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Customer Retention
              </Typography>
              <Typography variant="h4" component="div">
                {customerRetentionRate}%
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                Average retention rate
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Conversion Rate
              </Typography>
              <Typography variant="h4" component="div">
                {conversionRate}%
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                Orders per customer
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Top Performing State
              </Typography>
              <Typography variant="h4" component="div">
                {topPerformingState}
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                Leading in sales performance
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* Demographics Section */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Customer Demographics
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="subtitle2" gutterBottom>
                    Gender Distribution
                  </Typography>
                  <Box sx={{ height: 200 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={genderData}
                          cx="50%"
                          cy="50%"
                          innerRadius={40}
                          outerRadius={60}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {genderData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={GENDER_COLORS[index % GENDER_COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2" gutterBottom>
                    Age Group Distribution
                  </Typography>
                  <Box sx={{ height: 200 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={ageGroupData}
                          cx="50%"
                          cy="50%"
                          innerRadius={40}
                          outerRadius={60}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {ageGroupData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={AGE_COLORS[index % AGE_COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* State Distribution Chart */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                State Distribution
              </Typography>
              <Box sx={{ height: 200 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stateData}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={60}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {stateData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard; 