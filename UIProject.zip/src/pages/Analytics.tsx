import React, { useState, useMemo } from 'react';
import { Box, Grid, Card, CardContent, Typography, FormControl, InputLabel, Select, MenuItem, SelectChangeEvent } from '@mui/material';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, Legend, Area } from 'recharts';
import { useTheme as useCustomTheme } from '../context/ThemeContext';

// Constants from generate_data.py
const STATES = ['Maharashtra', 'Karnataka', 'Delhi', 'Tamil Nadu', 'Gujarat', 'Rajasthan', 'Telangana', 'West Bengal'];
const CITIES = {
  'Maharashtra': ['Mumbai', 'Pune'],
  'Karnataka': ['Bangalore'],
  'Delhi': ['Delhi'],
  'Tamil Nadu': ['Chennai', 'Coimbatore'],
  'Gujarat': ['Ahmedabad'],
  'Rajasthan': ['Jaipur'],
  'Telangana': ['Hyderabad'],
  'West Bengal': ['Kolkata']
};

const PRODUCTS = {
  'Trousers': ['Classic', 'Slim', 'Tailored'],
  'Blazers': ['Single-Breasted', 'Double-Breasted', 'Notch'],
  'Skirts': ['Pencil', 'A-Line', 'Pleated'],
  'Shirts': ['Dress', 'Oxford', 'Button-Down'],
  'Ties': ['Silk', 'Knit', 'Patterned'],
  'Belts': ['Leather', 'Buckle', 'Formal']
};

const COLORS = ['#FF9933', '#2C3E50', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEEAD', '#D4A5A5'];

// Helper function to generate dates
const generateDateRange = () => {
  const startDate = new Date('2022-03-01');
  const today = new Date();
  const dates = [];
  
  for (let d = new Date(startDate); d <= today; d.setDate(d.getDate() + 1)) {
    dates.push(new Date(d));
  }
  
  return dates;
};

// Helper function to format date
const formatDate = (date: Date) => {
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
};

// Modify the generateDummyData function to include more realistic patterns
const generateDummyData = () => {
  const data = [];
  const today = new Date();
  const days = 90; // Generate 90 days of data

  for (let i = 0; i < days; i++) {
    const date = new Date(today);
    date.setDate(date.getDate() - (days - 1 - i));
    
    const day = date.getDate();
    const month = date.toLocaleString('default', { month: 'short' });
    const year = date.getFullYear();
    
    // Generate more realistic base values
    const baseRevenue = 25000 + Math.random() * 5000; // Base revenue between 25,000-30,000
    const baseSales = 250 + Math.random() * 50; // Base sales between 250-300
    
    // Randomly select a state and its corresponding city
    const randomState = STATES[Math.floor(Math.random() * STATES.length)];
    const stateCities = CITIES[randomState as keyof typeof CITIES];
    const randomCity = stateCities[Math.floor(Math.random() * stateCities.length)];
    
    // Randomly select a product and its variant
    const productKeys = Object.keys(PRODUCTS);
    const randomProduct = productKeys[Math.floor(Math.random() * productKeys.length)];
    const productVariants = PRODUCTS[randomProduct as keyof typeof PRODUCTS];
    const randomVariant = productVariants[Math.floor(Math.random() * productVariants.length)];
    
    data.push({
      date: `${day} ${month} ${year}`,
      revenue: baseRevenue,
      sales: baseSales,
      orders: Math.floor(200 + Math.random() * 40), // Daily orders between 200-240
      customers: Math.floor(160 + Math.random() * 30), // Daily customers between 160-190
      quantity: Math.floor(50 + Math.random() * 10), // Daily quantity between 50-60
      product: randomProduct,
      state: randomState,
      city: randomCity,
      variant: randomVariant
    });
  }
  
  return data;
};

interface MonthlyComparisonData {
  [year: string]: {
    [month: string]: {
      revenue: number;
      sales: number;
      count: number;
    };
  };
}

interface SeasonalFactors {
  [key: string]: {
    sum: number;
    count: number;
  };
}

interface DemographicData {
  name: string;
  value: number;
}

interface StockItem {
  name: string;
  current: number;
  optimal: number;
  reorderPoint: number;
  turnover: number;
  daysInStock: number;
}

interface SampleData {
  revenue: { month: string; value: number; }[];
  sales: { month: string; value: number; }[];
  stateData: { name: string; value: number; growth: number; }[];
  productData: { name: string; value: number; growth: number; }[];
  cityData: { name: string; value: number; growth: number; }[];
  productTrends: { name: string; current: number; previous: number; }[];
  monthlyComparison: MonthlyComparisonData;
  predictiveData: {
    nextMonthRevenue: number;
    nextMonthOrders: number;
    confidence: number;
    trend: string;
    seasonalFactors: SeasonalFactors;
  };
  inventoryData: {
    currentStock: StockItem[];
  };
  genderData: DemographicData[];
  ageData: DemographicData[];
}

// Update the sampleData object to use realistic values
const sampleData: SampleData = {
  revenue: generateDummyData().map(item => ({
    month: item.date,
    value: item.revenue
  })),
  sales: generateDummyData().map(item => ({
    month: item.date,
    value: item.sales
  })),
  stateData: STATES.map(state => ({
    name: state,
    value: Math.floor(Math.random() * 100000) + 100000, // Revenue between 100,000-200,000
    growth: Math.floor(Math.random() * 40) - 20 // Growth between -20% to +20%
  })),
  productData: Object.entries(PRODUCTS).map(([product, variants]) => ({
    name: product,
    value: Math.floor(Math.random() * 50000) + 50000, // Revenue between 50,000-100,000
    growth: Math.floor(Math.random() * 30) - 10 // Growth between -10% to +20%
  })),
  cityData: Object.values(CITIES).flat().map(city => ({
    name: city,
    value: Math.floor(Math.random() * 30000) + 20000, // Revenue between 20,000-50,000
    growth: Math.floor(Math.random() * 35) - 15 // Growth between -15% to +20%
  })),
  productTrends: Object.entries(PRODUCTS).map(([product, variants]) => {
    const current = Math.floor(Math.random() * 50000) + 50000; // Current revenue between 50,000-100,000
    return {
      name: product,
      current,
      previous: Math.floor(current * (1 + Math.random() * 0.2 - 0.1)) // Previous revenue with ±10% variation
    };
  }),
  monthlyComparison: generateDummyData().reduce((acc: MonthlyComparisonData, item) => {
    const [day, month, year] = item.date.split(' ');
    
    if (!acc[year]) {
      acc[year] = {};
    }
    
    if (!acc[year][month]) {
      acc[year][month] = {
        revenue: 0,
        sales: 0,
        count: 0
      };
    }
    
    acc[year][month].revenue += item.revenue;
    acc[year][month].sales += item.sales;
    acc[year][month].count += 1;
    
    return acc;
  }, {}),
  predictiveData: {
    nextMonthRevenue: Math.round(
      generateDummyData().slice(-30).reduce((sum, item) => sum + item.revenue, 0) / 30 * 1.15 // 15% growth prediction
    ),
    nextMonthOrders: Math.round(
      generateDummyData().slice(-30).reduce((sum, item) => sum + item.sales, 0) / 30 * 1.15 // 15% growth prediction
    ),
    confidence: 85,
    trend: 'up',
    seasonalFactors: generateDummyData().slice(-180).reduce((acc: SeasonalFactors, item) => {
      const month = item.date.split(' ')[1];
      if (!acc[month]) {
        acc[month] = { sum: 0, count: 0 };
      }
      acc[month].sum += item.revenue;
      acc[month].count += 1;
      return acc;
    }, {})
  },
  inventoryData: {
    currentStock: Object.entries(PRODUCTS).map(([product, variants]) => ({
      name: product,
      current: Math.floor(Math.random() * 500) + 500, // Current stock between 500-1000
      optimal: 1000,
      reorderPoint: 300,
      turnover: Math.floor(Math.random() * 5) + 2, // Turnover between 2-7
      daysInStock: Math.floor(Math.random() * 30) + 15 // Days in stock between 15-45
    }))
  },
  genderData: [
    { name: 'Male', value: 65 },
    { name: 'Female', value: 35 }
  ],
  ageData: [
    { name: '10-18', value: 15 },
    { name: '19-35', value: 55 },
    { name: '36-70', value: 30 }
  ]
};

const Analytics = () => {
  const theme = useCustomTheme();
  const [timeFrame, setTimeFrame] = useState<'daily' | 'weekly' | 'monthly'>('monthly');
  const [selectedState, setSelectedState] = useState<string>('all');
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<string>('all');
  const [selectedGender, setSelectedGender] = useState<string>('all');
  const [selectedAgeGroup, setSelectedAgeGroup] = useState<string>('all');

  const handleTimeFrameChange = (event: SelectChangeEvent) => {
    setTimeFrame(event.target.value as 'daily' | 'weekly' | 'monthly');
  };

  const handleStateChange = (event: SelectChangeEvent) => {
    setSelectedState(event.target.value);
    setSelectedCity('all'); // Reset city when state changes
  };

  const handleCityChange = (event: SelectChangeEvent) => {
    setSelectedCity(event.target.value);
  };

  const handleProductChange = (event: SelectChangeEvent) => {
    setSelectedProduct(event.target.value);
  };

  const handleGenderChange = (event: SelectChangeEvent) => {
    setSelectedGender(event.target.value);
  };

  const handleAgeGroupChange = (event: SelectChangeEvent) => {
    setSelectedAgeGroup(event.target.value);
  };

  // Filter cities based on selected state
  const availableCities = selectedState === 'all' 
    ? Object.values(CITIES).flat()
    : CITIES[selectedState as keyof typeof CITIES] || [];

  // Update the filtering logic to use realistic scaling factors
  const filteredData = useMemo(() => {
    let filtered = { ...sampleData };

    // Filter by state
    if (selectedState !== 'all') {
      filtered.stateData = filtered.stateData.filter(item => item.name === selectedState);
      filtered.cityData = filtered.cityData.filter(item => 
        CITIES[selectedState as keyof typeof CITIES]?.includes(item.name) || false
      );
      // Filter revenue and sales based on state
      const stateValue = filtered.stateData[0]?.value || 0;
      const stateScale = stateValue / 150000; // Base value of 150,000
      filtered.revenue = filtered.revenue.map(item => ({
        ...item,
        value: item.value * stateScale
      }));
      filtered.sales = filtered.sales.map(item => ({
        ...item,
        value: item.value * stateScale
      }));
    }

    // Filter by city
    if (selectedCity !== 'all') {
      filtered.cityData = filtered.cityData.filter(item => item.name === selectedCity);
      // Further adjust revenue and sales based on city
      const cityValue = filtered.cityData[0]?.value || 0;
      const cityScale = cityValue / 35000; // Base value of 35,000
      filtered.revenue = filtered.revenue.map(item => ({
        ...item,
        value: item.value * cityScale
      }));
      filtered.sales = filtered.sales.map(item => ({
        ...item,
        value: item.value * cityScale
      }));
    }

    // Filter by product
    if (selectedProduct !== 'all') {
      filtered.productData = filtered.productData.filter(item => item.name === selectedProduct);
      // Adjust revenue and sales based on product
      const productValue = filtered.productData[0]?.value || 0;
      const productScale = productValue / 75000; // Base value of 75,000
      filtered.revenue = filtered.revenue.map(item => ({
        ...item,
        value: item.value * productScale
      }));
      filtered.sales = filtered.sales.map(item => ({
        ...item,
        value: item.value * productScale
      }));
    }

    // Filter by gender
    if (selectedGender !== 'all') {
      filtered.genderData = filtered.genderData.filter(item => 
        item.name.toLowerCase() === selectedGender
      );
      // Adjust revenue and sales based on gender distribution
      const genderValue = filtered.genderData[0]?.value || 0;
      const genderScale = genderValue / 50; // Base percentage of 50%
      filtered.revenue = filtered.revenue.map(item => ({
        ...item,
        value: item.value * genderScale
      }));
      filtered.sales = filtered.sales.map(item => ({
        ...item,
        value: item.value * genderScale
      }));
    }

    // Filter by age group
    if (selectedAgeGroup !== 'all') {
      filtered.ageData = filtered.ageData.filter(item => item.name === selectedAgeGroup);
      // Adjust revenue and sales based on age group
      const ageValue = filtered.ageData[0]?.value || 0;
      const ageScale = ageValue / 33.33; // Base percentage of 33.33%
      filtered.revenue = filtered.revenue.map(item => ({
        ...item,
        value: item.value * ageScale
      }));
      filtered.sales = filtered.sales.map(item => ({
        ...item,
        value: item.value * ageScale
      }));
    }

    // Apply time frame filter with realistic scaling
    if (timeFrame === 'monthly') {
      // Aggregate data by month
      const monthlyData = filtered.revenue.reduce((acc: { [key: string]: { revenue: number; sales: number; count: number } }, item) => {
        const month = item.month.split(' ')[1] + ' ' + item.month.split(' ')[2];
        if (!acc[month]) {
          acc[month] = { revenue: 0, sales: 0, count: 0 };
        }
        acc[month].revenue += item.value;
        acc[month].sales += filtered.sales.find(s => s.month === item.month)?.value || 0;
        acc[month].count += 1;
        return acc;
      }, {});

      filtered.revenue = Object.entries(monthlyData).map(([month, data]) => ({
        month,
        value: data.revenue / data.count // Average monthly revenue
      }));

      filtered.sales = Object.entries(monthlyData).map(([month, data]) => ({
        month,
        value: data.sales / data.count // Average monthly sales
      }));
    } else if (timeFrame === 'daily') {
      // Show last 30 days
      filtered.revenue = filtered.revenue.slice(-30);
      filtered.sales = filtered.sales.slice(-30);
    } else if (timeFrame === 'weekly') {
      // Aggregate data by week
      const weeklyData = filtered.revenue.reduce((acc: { [key: string]: { revenue: number; sales: number; count: number } }, item) => {
        const date = new Date(item.month);
        const weekStart = new Date(date);
        weekStart.setDate(date.getDate() - date.getDay());
        const weekKey = weekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        
        if (!acc[weekKey]) {
          acc[weekKey] = { revenue: 0, sales: 0, count: 0 };
        }
        acc[weekKey].revenue += item.value;
        acc[weekKey].sales += filtered.sales.find(s => s.month === item.month)?.value || 0;
        acc[weekKey].count += 1;
        return acc;
      }, {});

      filtered.revenue = Object.entries(weeklyData).map(([week, data]) => ({
        month: week,
        value: data.revenue / data.count // Average weekly revenue
      }));

      filtered.sales = Object.entries(weeklyData).map(([week, data]) => ({
        month: week,
        value: data.sales / data.count // Average weekly sales
      }));
    }

    return filtered;
  }, [timeFrame, selectedState, selectedCity, selectedProduct, selectedGender, selectedAgeGroup]);

  // Calculate detailed analytics
  const analytics = useMemo(() => {
    const currentRevenue = filteredData.revenue[filteredData.revenue.length - 1]?.value || 0;
    const previousRevenue = filteredData.revenue[filteredData.revenue.length - 2]?.value || 0;
    const currentSales = filteredData.sales[filteredData.sales.length - 1]?.value || 0;
    const previousSales = filteredData.sales[filteredData.sales.length - 2]?.value || 0;

    // Calculate product growth rates
    const productGrowth = filteredData.productTrends.map(product => ({
      ...product,
      growth: ((product.current - product.previous) / product.previous) * 100
    }));

    // Calculate state performance - using growth directly from stateData
    const statePerformance = filteredData.stateData.map(state => ({
      name: state.name,
      value: state.value,
      growth: state.growth
    }));

    return {
      productGrowth,
      statePerformance,
      revenueGrowth: previousRevenue ? ((currentRevenue - previousRevenue) / previousRevenue) * 100 : 0,
      salesGrowth: previousSales ? ((currentSales - previousSales) / previousSales) * 100 : 0,
      averageOrderValue: currentSales ? currentRevenue / currentSales : 0,
      totalOrders: filteredData.sales.reduce((sum, item) => sum + item.value, 0),
      totalRevenue: filteredData.revenue.reduce((sum, item) => sum + item.value, 0)
    };
  }, [filteredData]);

  return (
    <Box>
      {/* Filters */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3, flexWrap: 'wrap', gap: 2 }}>
        <Typography variant="h4">Detailed Analytics</Typography>
        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>Time Frame</InputLabel>
            <Select value={timeFrame} label="Time Frame" onChange={handleTimeFrameChange}>
              <MenuItem value="daily">Daily</MenuItem>
              <MenuItem value="weekly">Weekly</MenuItem>
              <MenuItem value="monthly">Monthly</MenuItem>
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>State</InputLabel>
            <Select value={selectedState} label="State" onChange={handleStateChange}>
              <MenuItem value="all">All States</MenuItem>
              {STATES.map(state => (
                <MenuItem key={state} value={state}>{state}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>City</InputLabel>
            <Select value={selectedCity} label="City" onChange={handleCityChange}>
              <MenuItem value="all">All Cities</MenuItem>
              {availableCities.map(city => (
                <MenuItem key={city} value={city}>{city}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>Product</InputLabel>
            <Select value={selectedProduct} label="Product" onChange={handleProductChange}>
              <MenuItem value="all">All Products</MenuItem>
              {Object.keys(PRODUCTS).map(product => (
                <MenuItem key={product} value={product}>{product}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>Gender</InputLabel>
            <Select value={selectedGender} label="Gender" onChange={handleGenderChange}>
              <MenuItem value="all">All</MenuItem>
              <MenuItem value="male">Male</MenuItem>
              <MenuItem value="female">Female</MenuItem>
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>Age Group</InputLabel>
            <Select value={selectedAgeGroup} label="Age Group" onChange={handleAgeGroupChange}>
              <MenuItem value="all">All Ages</MenuItem>
              <MenuItem value="10-18">10-18</MenuItem>
              <MenuItem value="19-35">19-35</MenuItem>
              <MenuItem value="36-70">36-70</MenuItem>
            </Select>
          </FormControl>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {/* Revenue Trend */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Revenue Trend
              </Typography>
              <Box sx={{ height: 300 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={filteredData.revenue}>
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#FF9933"
                      strokeWidth={2}
                      dot={{ fill: '#FF9933', strokeWidth: 2 }}
                    />
                    <defs>
                      <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#FF9933" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#FF9933" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke="none"
                      fill="url(#revenueGradient)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Sales Trend */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Sales Trend
              </Typography>
              <Box sx={{ height: 300 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={filteredData.sales}>
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#2C3E50"
                      strokeWidth={2}
                      dot={{ fill: '#2C3E50', strokeWidth: 2 }}
                    />
                    <defs>
                      <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#2C3E50" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#2C3E50" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke="none"
                      fill="url(#salesGradient)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Product Growth Analysis */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Product Growth Analysis
              </Typography>
              <Box sx={{ height: 300 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analytics.productGrowth}>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="growth" fill="#FF9933" name="Growth Rate (%)" />
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* State Performance */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                State Performance & Growth
              </Typography>
              <Box sx={{ height: 300 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analytics.statePerformance}>
                    <XAxis 
                      dataKey="name" 
                      angle={-45}
                      textAnchor="end"
                      height={100}
                      interval={0}
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis />
                    <Tooltip 
                      formatter={(value: number) => [`${value.toFixed(1)}%`, 'Growth Rate']}
                      labelStyle={{ fontWeight: 'bold' }}
                    />
                    <Bar 
                      dataKey="growth" 
                      fill="#4ECDC4" 
                      name="Growth Rate (%)"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* City-wise Performance */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                City-wise Sales Distribution
              </Typography>
              <Box sx={{ height: 400 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={filteredData.cityData}>
                    <XAxis 
                      dataKey="name" 
                      angle={-45}
                      textAnchor="end"
                      height={100}
                      interval={0}
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis />
                    <Tooltip 
                      formatter={(value: number) => [`${value.toLocaleString()} units`, 'Sales Volume']}
                      labelStyle={{ fontWeight: 'bold' }}
                    />
                    <Bar 
                      dataKey="value" 
                      fill="#45B7D1" 
                      name="Sales Volume"
                      radius={[4, 4, 0, 0]}
                      barSize={30}
                      maxBarSize={40}
                    />
                    <defs>
                      <linearGradient id="cityGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#45B7D1" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#45B7D1" stopOpacity={0.2}/>
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </Box>
              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Top Performing Cities
                </Typography>
                <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                  {[...filteredData.cityData]
                    .sort((a, b) => b.value - a.value)
                    .slice(0, 3)
                    .map((city, index) => (
                      <Box 
                        key={index} 
                        sx={{ 
                          bgcolor: 'primary.light',
                          p: 1.5,
                          borderRadius: 1,
                          minWidth: 150,
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'center'
                        }}
                      >
                        <Typography variant="body2" color="text.primary" sx={{ fontWeight: 'bold' }}>
                          {city.name}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {city.value.toLocaleString()} units
                        </Typography>
                      </Box>
                    ))}
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Predictive Analytics */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Predictive Analytics
              </Typography>
              <Box sx={{ height: 300 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart 
                    data={Object.entries(filteredData.predictiveData.seasonalFactors).map(([month, data]) => ({
                      month,
                      factor: data.sum / data.count
                    }))}
                  >
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="factor"
                      stroke="#FF9933"
                      name="Seasonal Factor"
                      strokeWidth={2}
                      dot={{ fill: '#FF9933', strokeWidth: 2 }}
                    />
                    <defs>
                      <linearGradient id="predictiveGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#FF9933" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#FF9933" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Area
                      type="monotone"
                      dataKey="factor"
                      stroke="none"
                      fill="url(#predictiveGradient)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </Box>
              <Box sx={{ mt: 2, display: 'flex', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="subtitle2" color="text.secondary">
                    Next Month Revenue
                  </Typography>
                  <Typography variant="h6" color={filteredData.predictiveData.trend === 'up' ? 'success.main' : 'error.main'}>
                    ₹{filteredData.predictiveData.nextMonthRevenue.toLocaleString()}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="subtitle2" color="text.secondary">
                    Confidence Level
                  </Typography>
                  <Typography variant="h6">
                    {filteredData.predictiveData.confidence}%
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Inventory Analytics */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Inventory Analytics
              </Typography>
              <Box sx={{ height: 300 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={filteredData.inventoryData.currentStock}>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar
                      dataKey="current"
                      fill="#4ECDC4"
                      name="Current Stock"
                    />
                    <Bar
                      dataKey="optimal"
                      fill="#45B7D1"
                      name="Optimal Level"
                    />
                    <Bar
                      dataKey="reorderPoint"
                      fill="#FF6B6B"
                      name="Reorder Point"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </Box>
              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Stock Turnover
                </Typography>
                <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                  {filteredData.inventoryData.currentStock
                    .sort((a, b) => b.turnover - a.turnover)
                    .slice(0, 3)
                    .map((item, index) => (
                      <Box 
                        key={index} 
                        sx={{ 
                          bgcolor: 'primary.light',
                          p: 1.5,
                          borderRadius: 1,
                          minWidth: 150,
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'center'
                        }}
                      >
                        <Typography variant="body2" color="text.primary" sx={{ fontWeight: 'bold' }}>
                          {item.name}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {item.turnover.toFixed(1)}x
                        </Typography>
                      </Box>
                    ))}
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Analytics; 