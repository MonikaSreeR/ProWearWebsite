import { Grid, Card, CardContent, Typography, Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';

// Dummy customer data
const customers = [
  { id: 1, gender: 'Male', age: 35, city: 'Mumbai', totalSpent: 45000 },
  { id: 2, gender: 'Female', age: 28, city: 'Bangalore', totalSpent: 38000 },
  { id: 3, gender: 'Male', age: 42, city: 'Delhi', totalSpent: 52000 },
  { id: 4, gender: 'Female', age: 31, city: 'Chennai', totalSpent: 42000 },
  { id: 5, gender: 'Male', age: 45, city: 'Ahmedabad', totalSpent: 48000 },
  { id: 6, gender: 'Female', age: 29, city: 'Mumbai', totalSpent: 35000 },
  { id: 7, gender: 'Male', age: 38, city: 'Bangalore', totalSpent: 55000 },
  { id: 8, gender: 'Female', age: 33, city: 'Delhi', totalSpent: 41000 },
  { id: 9, gender: 'Male', age: 40, city: 'Chennai', totalSpent: 49000 },
  { id: 10, gender: 'Female', age: 27, city: 'Ahmedabad', totalSpent: 36000 },
];

const ageGroupData = [
  { group: '10-18', count: 5, revenue: 150000 },
  { group: '19-35', count: 25, revenue: 450000 },
  { group: '36-70', count: 20, revenue: 300000 },
];

const genderData = [
  { gender: 'Male', count: 55, revenue: 550000 },
  { gender: 'Female', count: 45, revenue: 450000 },
];

const Customers = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Customers
      </Typography>
      <Grid container spacing={3}>
        {/* Customer Profiles */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Customer Profiles
              </Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Gender</TableCell>
                      <TableCell>Age</TableCell>
                      <TableCell>City</TableCell>
                      <TableCell>Total Spent</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {customers.map((customer) => (
                      <TableRow key={customer.id}>
                        <TableCell>{customer.gender}</TableCell>
                        <TableCell>{customer.age}</TableCell>
                        <TableCell>{customer.city}</TableCell>
                        <TableCell>₹{customer.totalSpent.toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Customer Demographics */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Age Group Distribution
              </Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Age Group</TableCell>
                      <TableCell>Count</TableCell>
                      <TableCell>Revenue</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {ageGroupData.map((group) => (
                      <TableRow key={group.group}>
                        <TableCell>{group.group}</TableCell>
                        <TableCell>{group.count}</TableCell>
                        <TableCell>₹{group.revenue.toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Gender Distribution */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Gender Distribution
              </Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Gender</TableCell>
                      <TableCell>Count</TableCell>
                      <TableCell>Revenue</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {genderData.map((data) => (
                      <TableRow key={data.gender}>
                        <TableCell>{data.gender}</TableCell>
                        <TableCell>{data.count}</TableCell>
                        <TableCell>₹{data.revenue.toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Customer Insights */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Customer Insights
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} md={4}>
                  <Typography color="textSecondary">Average Age</Typography>
                  <Typography variant="h4">35</Typography>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Typography color="textSecondary">Average Spend</Typography>
                  <Typography variant="h4">₹42,500</Typography>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Typography color="textSecondary">Customer Retention</Typography>
                  <Typography variant="h4">85%</Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Customers; 