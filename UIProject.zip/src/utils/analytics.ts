export interface DataPoint {
  revenue: number;
  orders: number;
  customers: number;
  quantity?: number;
  product?: string;
  state?: string;
  city?: string;
  variant?: string;
  date?: string;
  [key: string]: any;
}

export interface ProcessedData {
  totalRevenue: number;
  totalOrders: number;
  totalCustomers: number;
  totalQuantity: number;
  averageOrderValue: number;
  averageCustomerValue: number;
  averageQuantityPerOrder: number;
}

export const processData = (data: DataPoint[]): ProcessedData => {
  const processedData = data.map(item => ({
    ...item,
    revenue: Number(item.revenue) || 0,
    orders: Number(item.orders) || 0,
    customers: Number(item.customers) || 0,
    quantity: Number(item.quantity) || 0
  }));

  const totalRevenue = processedData.reduce((sum, item) => sum + (item.revenue || 0), 0);
  const totalOrders = processedData.reduce((sum, item) => sum + (item.orders || 0), 0);
  const totalCustomers = processedData.reduce((sum, item) => sum + (item.customers || 0), 0);
  const totalQuantity = processedData.reduce((sum, item) => sum + (item.quantity || 0), 0);

  const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
  const averageCustomerValue = totalCustomers > 0 ? totalRevenue / totalCustomers : 0;
  const averageQuantityPerOrder = totalOrders > 0 ? totalQuantity / totalOrders : 0;

  return {
    totalRevenue,
    totalOrders,
    totalCustomers,
    totalQuantity,
    averageOrderValue,
    averageCustomerValue,
    averageQuantityPerOrder
  };
};

export const getTimeFrameData = (): DataPoint[] => {
  // Generate dummy data for the current time frame
  const data: DataPoint[] = [];
  const now = new Date();
  
  for (let i = 0; i < 30; i++) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    data.push({
      date: date.toISOString().split('T')[0],
      revenue: Math.floor(Math.random() * 1000000) + 500000,
      orders: Math.floor(Math.random() * 100) + 50,
      customers: Math.floor(Math.random() * 80) + 40,
      quantity: Math.floor(Math.random() * 200) + 100,
      product: ['Blazers', 'Trousers', 'Shirts', 'Skirts', 'Ties'][Math.floor(Math.random() * 5)],
      state: ['Maharashtra', 'Delhi', 'Karnataka', 'Gujarat', 'Tamil Nadu'][Math.floor(Math.random() * 5)],
      city: ['Mumbai', 'Delhi', 'Bangalore', 'Ahmedabad', 'Chennai'][Math.floor(Math.random() * 5)],
      variant: ['Classic', 'Slim Fit', 'Regular', 'High-Waist'][Math.floor(Math.random() * 4)]
    });
  }
  
  return data;
}; 