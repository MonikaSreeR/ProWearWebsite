import { Box, Typography } from '@mui/material';
import { LocalMall as MallIcon } from '@mui/icons-material';

const Logo = () => {
  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 1,
        p: 1,
      }}
    >
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: 40,
          height: 40,
          borderRadius: '12px',
          bgcolor: '#FF9933',
          boxShadow: '0 2px 8px rgba(255, 153, 51, 0.3)',
        }}
      >
        <MallIcon sx={{ fontSize: 24, color: 'white' }} />
      </Box>
      <Typography
        variant="h6"
        sx={{
          fontWeight: 700,
          background: 'linear-gradient(45deg, #FF9933 30%, #F57C00 90%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          letterSpacing: '0.5px',
        }}
      >
        ProWear
      </Typography>
    </Box>
  );
};

export default Logo; 