import React, { useState, useRef, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  List,
  ListItemText,
  CircularProgress,
  ListItemButton,
  Collapse,
  IconButton,
  Dialog,
} from '@mui/material';
import {
  ExpandLess,
  ExpandMore,
  TrendingUp as TrendingUpIcon,
  Inventory as InventoryIcon,
  People as PeopleIcon,
  ShoppingCart as ShoppingCartIcon,
  Close as CloseIcon,
  SmartToy as BotIcon,
} from '@mui/icons-material';

interface Message {
  text: string;
  isUser: boolean;
  timestamp: string;
}

interface ChatBotProps {
  onClose: () => void;
}

const ChatBot: React.FC<ChatBotProps> = ({ onClose }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [openCategories, setOpenCategories] = useState<{ [key: string]: boolean }>({
    revenue: true,
    products: true,
    customers: true,
    orders: true,
  });
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const processQuery = (question: string): string => {
    if (question.includes('current revenue')) {
      return `Current Revenue Analysis:\n\n` +
        `Total Revenue: ₹850,000\n` +
        `Previous Period: ₹750,000\n` +
        `Growth: 13.3%\n` +
        `Trend: 📈 Increasing`;
    }
    else if (question.includes('top selling products')) {
      return `Top Selling Products:\n\n` +
        `1. Blazers (Single-Breasted): 850 units\n` +
        `2. Trousers (Classic): 780 units\n` +
        `3. Shirts (Dress): 720 units\n` +
        `4. Skirts (Pencil): 680 units\n` +
        `5. Ties (Silk): 650 units`;
    }
    else if (question.includes('main customers')) {
      return `Main Customer Demographics:\n\n` +
        `Primary Customer Base:\n` +
        `• Age Group: 25-40 years\n` +
        `• Gender: 60% Male, 40% Female\n` +
        `• Occupation: 70% Professionals\n` +
        `• Income Level: ₹50,000 - ₹150,000`;
    }
    else if (question.includes('total number of orders')) {
      return `Order Statistics:\n\n` +
        `Total Orders: 1,250\n` +
        `Average Daily Orders: 42\n` +
        `Orders Growth: 15%\n` +
        `Order Completion Rate: 98%`;
    }
    else {
      return "I apologize, but I couldn't understand your question. Please select one of the predefined questions from the list below.";
    }
  };

  const handleCategoryClick = (category: string) => {
    setOpenCategories(prev => ({
      ...prev,
      [category]: !prev[category],
    }));
  };

  const handleQuestionSelect = (question: string) => {
    // Add user message
    setMessages(prev => [...prev, {
      text: question,
      isUser: true,
      timestamp: new Date().toLocaleTimeString()
    }]);
    setIsProcessing(true);

    // Process the question and add response
    setTimeout(() => {
      const response = processQuery(question);
      setMessages(prev => [...prev, {
        text: response,
        isUser: false,
        timestamp: new Date().toLocaleTimeString()
      }]);
      setIsProcessing(false);
    }, 1000);
  };

  return (
    <>
      <IconButton
        onClick={() => setIsOpen(true)}
        sx={{
          position: 'fixed',
          bottom: 16,
          right: 16,
          bgcolor: 'primary.main',
          color: 'white',
          '&:hover': {
            bgcolor: 'primary.dark',
          },
          zIndex: 1000,
          boxShadow: 3
        }}
      >
        <BotIcon sx={{ fontSize: 28 }} />
      </IconButton>

      <Dialog
        open={isOpen}
        onClose={onClose}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: {
            height: '80vh',
            maxHeight: '600px',
            display: 'flex',
            flexDirection: 'column'
          }
        }}
      >
        {/* Header */}
        <Box sx={{ 
          p: 2, 
          bgcolor: 'primary.main', 
          color: 'white',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Box sx={{ 
              width: 32, 
              height: 32, 
              bgcolor: 'white', 
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: 1
            }}>
              <Typography variant="h6" sx={{ color: 'primary.main', fontWeight: 'bold' }}>
                P
              </Typography>
            </Box>
            <Box>
              <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                ProWear
              </Typography>
              <Typography variant="caption" sx={{ opacity: 0.9, fontSize: '0.7rem' }}>
                Premium Clothing
              </Typography>
            </Box>
          </Box>
          <IconButton 
            onClick={() => setIsOpen(false)}
            sx={{ color: 'white' }}
          >
            <CloseIcon />
          </IconButton>
        </Box>

        {/* Question Categories - Fixed at top */}
        <Box sx={{ 
          p: 2, 
          borderBottom: 1, 
          borderColor: 'divider',
          bgcolor: 'background.paper'
        }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>
            Quick Questions:
          </Typography>
          <List dense>
            {/* Revenue & Sales */}
            <ListItemButton 
              onClick={() => handleQuestionSelect('What is our current revenue?')}
              sx={{ 
                borderRadius: 1,
                mb: 0.5,
                '&:hover': {
                  bgcolor: 'primary.light',
                  color: 'white',
                }
              }}
            >
              <ListItemText 
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <TrendingUpIcon sx={{ mr: 1, fontSize: 20 }} />
                    Current Revenue
                  </Box>
                }
              />
            </ListItemButton>

            {/* Products */}
            <ListItemButton 
              onClick={() => handleQuestionSelect('What are our top selling products?')}
              sx={{ 
                borderRadius: 1,
                mb: 0.5,
                '&:hover': {
                  bgcolor: 'primary.light',
                  color: 'white',
                }
              }}
            >
              <ListItemText 
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <InventoryIcon sx={{ mr: 1, fontSize: 20 }} />
                    Top Products
                  </Box>
                }
              />
            </ListItemButton>

            {/* Customers */}
            <ListItemButton 
              onClick={() => handleQuestionSelect('Who are our main customers?')}
              sx={{ 
                borderRadius: 1,
                mb: 0.5,
                '&:hover': {
                  bgcolor: 'primary.light',
                  color: 'white',
                }
              }}
            >
              <ListItemText 
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <PeopleIcon sx={{ mr: 1, fontSize: 20 }} />
                    Customer Demographics
                  </Box>
                }
              />
            </ListItemButton>

            {/* Orders */}
            <ListItemButton 
              onClick={() => handleQuestionSelect('What is the total number of orders?')}
              sx={{ 
                borderRadius: 1,
                mb: 0.5,
                '&:hover': {
                  bgcolor: 'primary.light',
                  color: 'white',
                }
              }}
            >
              <ListItemText 
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <ShoppingCartIcon sx={{ mr: 1, fontSize: 20 }} />
                    Order Statistics
                  </Box>
                }
              />
            </ListItemButton>
          </List>
        </Box>

        {/* Chat Messages - Scrollable */}
        <Box sx={{ 
          flex: 1, 
          overflow: 'auto',
          p: 2,
          display: 'flex',
          flexDirection: 'column',
          gap: 2
        }}>
          {messages.map((message, index) => (
            <Box
              key={index}
              sx={{
                display: 'flex',
                justifyContent: message.isUser ? 'flex-end' : 'flex-start',
                mb: 1
              }}
            >
              <Paper
                elevation={0}
                sx={{
                  p: 2,
                  maxWidth: '80%',
                  bgcolor: message.isUser ? 'primary.main' : 'grey.800',
                  color: message.isUser ? 'white' : 'white',
                  borderRadius: 2,
                  position: 'relative',
                  '& pre': {
                    whiteSpace: 'pre-wrap',
                    fontFamily: 'inherit',
                    margin: 0,
                    color: 'inherit'
                  }
                }}
              >
                <Typography 
                  variant="body2" 
                  sx={{ 
                    whiteSpace: 'pre-line',
                    color: message.isUser ? 'white' : 'white'
                  }}
                >
                  {message.text}
                </Typography>
                <Typography 
                  variant="caption" 
                  sx={{ 
                    display: 'block',
                    mt: 0.5,
                    opacity: 0.7,
                    fontSize: '0.7rem',
                    color: message.isUser ? 'white' : 'grey.300'
                  }}
                >
                  {message.timestamp}
                </Typography>
              </Paper>
            </Box>
          ))}
          {isProcessing && (
            <Box sx={{ display: 'flex', justifyContent: 'flex-start' }}>
              <Paper
                elevation={0}
                sx={{
                  p: 2,
                  bgcolor: 'grey.100',
                  borderRadius: 2,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 1
                }}
              >
                <CircularProgress size={16} />
                <Typography variant="body2">Processing...</Typography>
              </Paper>
            </Box>
          )}
          <div ref={chatEndRef} />
        </Box>
      </Dialog>
    </>
  );
};

export default ChatBot; 