import { Grid, Card, CardContent, Typography, Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Avatar, Chip, useTheme } from '@mui/material';
import { People as PeopleIcon, TrendingUp as TrendingUpIcon, Group as GroupIcon, EmojiPeople as EmojiPeopleIcon } from '@mui/icons-material';
import { useTheme as useCustomTheme } from '../context/ThemeContext';

// Dummy customer data
const customers = [
  { id: 1, gender: 'Male', age: 35, city: 'Mumbai', totalSpent: 45000 },
  { id: 2, gender: 'Female', age: 28, city: 'Bangalore', totalSpent: 38000 },
  { id: 3, gender: 'Male', age: 42, city: 'Delhi', totalSpent: 52000 },
  { id: 4, gender: 'Female', age: 31, city: 'Chennai', totalSpent: 42000 },
  { id: 5, gender: 'Male', age: 45, city: 'Ahmedabad', totalSpent: 48000 },
  { id: 6, gender: 'Female', age: 29, city: 'Mumbai', totalSpent: 35000 },
  { id: 7, gender: 'Male', age: 38, city: 'Bangalore', totalSpent: 55000 },
  { id: 8, gender: 'Female', age: 33, city: 'Delhi', totalSpent: 41000 },
  { id: 9, gender: 'Male', age: 40, city: 'Chennai', totalSpent: 49000 },
  { id: 10, gender: 'Female', age: 27, city: 'Ahmedabad', totalSpent: 36000 },
];

const ageGroupData = [
  { group: '10-18', count: 5, revenue: 150000 },
  { group: '19-35', count: 25, revenue: 450000 },
  { group: '36-70', count: 20, revenue: 300000 },
];

const genderData = [
  { gender: 'Male', count: 55, revenue: 550000 },
  { gender: 'Female', count: 45, revenue: 450000 },
];

const Customers = () => {
  const theme = useCustomTheme();
  const muiTheme = useTheme();

  const getCustomerStatus = (totalSpent: number) => {
    if (totalSpent > 50000) return <Chip label="VIP" color="primary" size="small" />;
    if (totalSpent > 40000) return <Chip label="Regular" color="success" size="small" />;
    return <Chip label="Standard" color="default" size="small" />;
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3, gap: 2 }}>
        <PeopleIcon sx={{ fontSize: 32, color: 'primary.main' }} />
        <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
          Customers
        </Typography>
      </Box>
      <Grid container spacing={3}>
        {/* Customer Profiles */}
        <Grid item xs={12}>
          <Card sx={{ 
            boxShadow: 3,
            border: `1px solid ${muiTheme.palette.primary.main}`,
            '&:hover': {
              boxShadow: 6,
              transform: 'translateY(-2px)',
              transition: 'all 0.3s ease-in-out'
            }
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 1 }}>
                <EmojiPeopleIcon sx={{ color: 'primary.main' }} />
                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                  Customer Profiles
                </Typography>
              </Box>
              <TableContainer component={Paper} sx={{ borderRadius: 2 }}>
                <Table>
                  <TableHead>
                    <TableRow sx={{ bgcolor: 'primary.main' }}>
                      <TableCell sx={{ color: 'white' }}>Customer</TableCell>
                      <TableCell sx={{ color: 'white' }}>Gender</TableCell>
                      <TableCell sx={{ color: 'white' }}>Age</TableCell>
                      <TableCell sx={{ color: 'white' }}>City</TableCell>
                      <TableCell sx={{ color: 'white' }}>Total Spent</TableCell>
                      <TableCell sx={{ color: 'white' }}>Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {customers.map((customer) => (
                      <TableRow key={customer.id} hover>
                        <TableCell>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Avatar sx={{ bgcolor: 'primary.main' }}>
                              {customer.gender === 'Male' ? 'M' : 'F'}
                            </Avatar>
                            <Typography>Customer {customer.id}</Typography>
                          </Box>
                        </TableCell>
                        <TableCell>{customer.gender}</TableCell>
                        <TableCell>{customer.age}</TableCell>
                        <TableCell>{customer.city}</TableCell>
                        <TableCell>
                          <Typography sx={{ color: 'primary.main', fontWeight: 'bold' }}>
                            ₹{customer.totalSpent.toLocaleString()}
                          </Typography>
                        </TableCell>
                        <TableCell>{getCustomerStatus(customer.totalSpent)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Customer Demographics */}
        <Grid item xs={12} md={6}>
          <Card sx={{ 
            boxShadow: 3,
            border: `1px solid ${muiTheme.palette.primary.main}`,
            '&:hover': {
              boxShadow: 6,
              transform: 'translateY(-2px)',
              transition: 'all 0.3s ease-in-out'
            }
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 1 }}>
                <GroupIcon sx={{ color: 'primary.main' }} />
                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                  Age Group Distribution
                </Typography>
              </Box>
              <TableContainer component={Paper} sx={{ borderRadius: 2 }}>
                <Table>
                  <TableHead>
                    <TableRow sx={{ bgcolor: 'primary.main' }}>
                      <TableCell sx={{ color: 'white' }}>Age Group</TableCell>
                      <TableCell sx={{ color: 'white' }}>Count</TableCell>
                      <TableCell sx={{ color: 'white' }}>Revenue</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {ageGroupData.map((group) => (
                      <TableRow key={group.group} hover>
                        <TableCell>{group.group}</TableCell>
                        <TableCell>{group.count}</TableCell>
                        <TableCell>
                          <Typography sx={{ color: 'primary.main', fontWeight: 'bold' }}>
                            ₹{group.revenue.toLocaleString()}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Gender Distribution */}
        <Grid item xs={12} md={6}>
          <Card sx={{ 
            boxShadow: 3,
            border: `1px solid ${muiTheme.palette.primary.main}`,
            '&:hover': {
              boxShadow: 6,
              transform: 'translateY(-2px)',
              transition: 'all 0.3s ease-in-out'
            }
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 1 }}>
                <PeopleIcon sx={{ color: 'primary.main' }} />
                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                  Gender Distribution
                </Typography>
              </Box>
              <TableContainer component={Paper} sx={{ borderRadius: 2 }}>
                <Table>
                  <TableHead>
                    <TableRow sx={{ bgcolor: 'primary.main' }}>
                      <TableCell sx={{ color: 'white' }}>Gender</TableCell>
                      <TableCell sx={{ color: 'white' }}>Count</TableCell>
                      <TableCell sx={{ color: 'white' }}>Revenue</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {genderData.map((data) => (
                      <TableRow key={data.gender} hover>
                        <TableCell>{data.gender}</TableCell>
                        <TableCell>{data.count}</TableCell>
                        <TableCell>
                          <Typography sx={{ color: 'primary.main', fontWeight: 'bold' }}>
                            ₹{data.revenue.toLocaleString()}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Customer Insights */}
        <Grid item xs={12}>
          <Card sx={{ 
            boxShadow: 3,
            border: `1px solid ${muiTheme.palette.primary.main}`,
            '&:hover': {
              boxShadow: 6,
              transform: 'translateY(-2px)',
              transition: 'all 0.3s ease-in-out'
            }
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 1 }}>
                <TrendingUpIcon sx={{ color: 'primary.main' }} />
                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                  Customer Insights
                </Typography>
              </Box>
              <Grid container spacing={3}>
                <Grid item xs={12} md={4}>
                  <Box sx={{ 
                    p: 2, 
                    borderRadius: 2, 
                    bgcolor: 'primary.light',
                    color: 'white',
                    textAlign: 'center'
                  }}>
                    <Typography variant="subtitle2" sx={{ mb: 1, opacity: 0.9 }}>
                      Average Age
                    </Typography>
                    <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                      35
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Box sx={{ 
                    p: 2, 
                    borderRadius: 2, 
                    bgcolor: 'primary.main',
                    color: 'white',
                    textAlign: 'center'
                  }}>
                    <Typography variant="subtitle2" sx={{ mb: 1, opacity: 0.9 }}>
                      Average Spend
                    </Typography>
                    <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                      ₹42,500
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Box sx={{ 
                    p: 2, 
                    borderRadius: 2, 
                    bgcolor: 'primary.dark',
                    color: 'white',
                    textAlign: 'center'
                  }}>
                    <Typography variant="subtitle2" sx={{ mb: 1, opacity: 0.9 }}>
                      Customer Retention
                    </Typography>
                    <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                      85%
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Customers; 