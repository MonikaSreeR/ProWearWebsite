import { Grid, Card, CardContent, Typography, Box, Switch, FormControlLabel, Button } from '@mui/material';
import { useTheme } from '../context/ThemeContext';

const Settings = () => {
  const { darkMode, toggleDarkMode } = useTheme();

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Settings
      </Typography>
      <Grid container spacing={3}>
        {/* Theme Settings */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Theme Settings
              </Typography>
              <FormControlLabel
                control={
                  <Switch
                    checked={darkMode}
                    onChange={toggleDarkMode}
                    color="primary"
                  />
                }
                label="Dark Mode"
              />
              <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
                Toggle between light and dark theme for the dashboard.
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* Data Refresh */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Data Management
              </Typography>
              <Button
                variant="contained"
                color="primary"
              >
                Refresh Data
              </Button>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
                Last updated: {new Date().toLocaleString()}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Settings; 