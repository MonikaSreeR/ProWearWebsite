import React, { createContext, useContext, useState, useCallback, useMemo, ReactNode } from 'react';

interface DataPoint {
  revenue: number;
  orders: number;
  customers: number;
  [key: string]: any;
}

interface StateDataPoint {
  name: string;
  value: number;
}

interface DataContextType {
  timeFrame: string;
  setTimeFrame: (timeFrame: string) => void;
  getTimeFrameData: () => DataPoint[];
  getXAxisKey: () => string;
  stateData: StateDataPoint[];
}

// Sample data
const monthlyData: DataPoint[] = [
  { month: 'Jan', revenue: 25000, orders: 1500, customers: 1200 },
  { month: 'Feb', revenue: 28000, orders: 1700, customers: 1400 },
  { month: 'Mar', revenue: 32000, orders: 1900, customers: 1600 },
  { month: 'Apr', revenue: 35000, orders: 2100, customers: 1800 },
  { month: 'May', revenue: 38000, orders: 2300, customers: 2000 },
  { month: 'Jun', revenue: 42000, orders: 2500, customers: 2200 },
];

const weeklyData: DataPoint[] = [
  { week: 'Week 1', revenue: 9500, orders: 600, customers: 500 },
  { week: 'Week 2', revenue: 10500, orders: 650, customers: 550 },
  { week: 'Week 3', revenue: 11500, orders: 700, customers: 600 },
  { week: 'Week 4', revenue: 12500, orders: 750, customers: 650 },
];

const dailyData: DataPoint[] = [
  { day: 'Mon', revenue: 3500, orders: 220, customers: 180 },
  { day: 'Tue', revenue: 3800, orders: 240, customers: 200 },
  { day: 'Wed', revenue: 4200, orders: 260, customers: 220 },
  { day: 'Thu', revenue: 4500, orders: 280, customers: 240 },
  { day: 'Fri', revenue: 4800, orders: 300, customers: 260 },
  { day: 'Sat', revenue: 5200, orders: 320, customers: 280 },
  { day: 'Sun', revenue: 5500, orders: 340, customers: 300 },
];

const stateData: StateDataPoint[] = [
  { name: 'Maharashtra', value: 45000 },
  { name: 'Karnataka', value: 38000 },
  { name: 'Delhi', value: 32000 },
  { name: 'Tamil Nadu', value: 28000 },
  { name: 'Gujarat', value: 25000 },
  { name: 'Kerala', value: 22000 },
  { name: 'West Bengal', value: 20000 },
  { name: 'Telangana', value: 18000 },
  { name: 'Rajasthan', value: 15000 },
];

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider = ({ children }: { children: ReactNode }) => {
  const [timeFrame, setTimeFrame] = useState('6months');

  const getTimeFrameData = useCallback(() => {
    switch (timeFrame) {
      case '6months':
        return monthlyData;
      case 'year':
        return monthlyData;
      case 'custom':
        return dailyData;
      default:
        return monthlyData;
    }
  }, [timeFrame]);

  const getXAxisKey = useCallback(() => {
    switch (timeFrame) {
      case '6months':
        return 'month';
      case 'year':
        return 'month';
      case 'custom':
        return 'day';
      default:
        return 'month';
    }
  }, [timeFrame]);

  const value = useMemo(() => ({
    timeFrame,
    setTimeFrame,
    getTimeFrameData,
    getXAxisKey,
    stateData,
  }), [timeFrame, getTimeFrameData, getXAxisKey]);

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}; 