# ProWear Sales Dashboard

A modern, responsive sales dashboard for ProWear: Premium Clothing, built with React, TypeScript, and Material-UI.

## Features

- Dark/Light theme support
- Responsive design
- Interactive charts and visualizations
- Real-time data updates
- Customer insights
- Product inventory management
- Chatbot interface
- Data export capabilities

## Pages

1. **Dashboard**
   - Revenue overview
   - Key metrics
   - Revenue trends
   - Geographic distribution

2. **Analytics**
   - Revenue analysis
   - Gender distribution
   - Age group analysis
   - State-wise performance

3. **Products**
   - Product catalog
   - Inventory status
   - Stock alerts
   - Performance metrics

4. **Customers**
   - Customer profiles
   - Demographics
   - Spending patterns
   - Customer insights

5. **Settings**
   - Theme customization
   - Chatbot interface
   - Data management

## Tech Stack

- React 18
- TypeScript
- Vite
- Material-UI
- Recharts
- React Router
- Axios

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/prowear-dashboard.git
   cd prowear-dashboard
   ```

2. Install dependencies:
   ```bash
   npm install
   # or
   yarn install
   ```

3. Start the development server:
   ```bash
   npm run dev
   # or
   yarn dev
   ```

4. Open [http://localhost:5173](http://localhost:5173) in your browser.

### Building for Production

```bash
npm run build
# or
yarn build
```

The build output will be in the `dist` directory.

## Project Structure

```
src/
├── components/     # Reusable components
├── context/       # React context providers
├── pages/         # Page components
├── types/         # TypeScript type definitions
├── utils/         # Utility functions
├── App.tsx        # Main application component
└── main.tsx       # Application entry point
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Material-UI for the component library
- Recharts for the charting library
- React Router for navigation 